Forex Currency Conversion Calculator

This Application was built to convert currency from one to other using provided conversion rate and lookup table.
It takes console input in the below format:

<ccy1> <amount1> in <ccy2>

ex: AUD 100.00 in USD

provides output in the below format:

<ccy1> <amout1> = <amount2> <ccy2>

ex: AUD 100.00 = USD 83.71

Getting Started:

This program can be deployed as an independent SpringBoot application by packaging into a jar and starting it up.

Prerequisites:
Installation of Java JRE 1.8
Copy generated jar and start it.
or
Import project as a Maven project and run it on IDE, ex: Eclipse/IntelliJ


Running the tests
Provided Unit test cases can be run on IDE by right click on ForexCcalculatorApplicationTests.java and Run option.

1) testConvertionOfAUDtoUSD: test case for AUD to USD conversion.
2) testConvertionOfAUDtoAUD: test case for AUD to AUD conversion.
3) testConvertionOfAUDtoDKK: test case for AUD to DKK conversion.
4) testConvertionOfJPYtoUSD: test case for JPY to USD conversion.
5) testConvertionOfKRWtoFJD: test case for KRW to FJD conversion.


Built With
Sprint Boot- Framework
Maven - Dependency Management
Junit - for test cases

Versioning
1.0

Authors
Praveen Bandidoddi

License
This project is licensed under the Cognizant Australia
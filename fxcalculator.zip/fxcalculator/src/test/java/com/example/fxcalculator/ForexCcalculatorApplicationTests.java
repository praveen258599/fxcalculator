package com.example.fxcalculator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ForexCcalculatorApplicationTests {

	@Test
	public void testConvertionOfAUDtoUSD() {
		String input = "AUD 100 in USD";
		String[] request=input.split(" ");
		ForexCcalculator calc=new ForexCcalculator();
		assertTrue("AUD 100.0 = USD 83.71".equalsIgnoreCase(calc.fxCalculator(request)));
	}

    @Test
    public void testConvertionOfAUDtoAUD() {
        String input = "AUD 100 in AUD";
        String[] request=input.split(" ");
        ForexCcalculator calc=new ForexCcalculator();
        assertTrue("AUD 100.0 = AUD 100.00".equalsIgnoreCase(calc.fxCalculator(request)));
    }

    @Test
    public void testConvertionOfAUDtoDKK() {
        String input = "AUD 100 in DKK";
        String[] request=input.split(" ");
        ForexCcalculator calc=new ForexCcalculator();
        assertTrue("AUD 100.0 = DKK 505.76".equalsIgnoreCase(calc.fxCalculator(request)));
    }

    @Test
    public void testConvertionOfJPYtoUSD() {
        String input = "JPY 100 in USD";
        String[] request=input.split(" ");
        ForexCcalculator calc=new ForexCcalculator();
        assertTrue("JPY 100.0 = USD 0.83".equalsIgnoreCase(calc.fxCalculator(request)));
    }

    @Test
    public void testConvertionOfKRWtoFJD() {
        String input = "KRW 1000.0 in FJD";
        String[] request=input.split(" ");
        ForexCcalculator calc=new ForexCcalculator();
        assertTrue("Unable to find rate for KRW/FJD".equals(calc.fxCalculator(request)));
    }

}

package com.example.fxcalculator;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;


/**
 * Reads configuration from application.yml file and loads in to respective maps.
 * currencies,conversion,lookup
 *
 * @author  Praveen Bandidoddi
 * @version 1.0
 * @since   2018-06-26
 */
@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "config")
public class AppConfiguration {

    private static HashMap<Integer,String> currencies;

    public  static HashMap<Integer,String> getCurrencies() {
        return currencies;
    }

    public void setCurrencies(HashMap<Integer, String> currencies) {
        this.currencies = currencies;
    }

    private static HashMap<String, Float> conversion;

    public  HashMap<String, Float> getConversion() {
        return conversion;
    }

    public void setConversion(HashMap<String, Float> conversion) {
        this.conversion = conversion;
    }


    private static HashMap<String, String> lookup;

    public static HashMap<String, String> getLookup() {
        return lookup;
    }

    public void setLookup(HashMap<String, String> lookup) {
        this.lookup = lookup;
    }
}

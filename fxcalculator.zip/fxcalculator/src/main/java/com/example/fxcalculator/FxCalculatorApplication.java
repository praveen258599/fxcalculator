package com.example.fxcalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

/**
 * This program reads input from user and calls fxCalculator for conversion
 * in a loop
 * @author  Praveen Bandidoddi
 * @version 1.0
 * @since   2018-06-26
 */
@SpringBootApplication
public class FxCalculatorApplication {

    public static void main(String[] args) {

        SpringApplication.run(FxCalculatorApplication.class, args);

        ForexCcalculator calc = new ForexCcalculator();
        while(true){
            // Read Inputs from Console: Source Currency, Amount and Destination Currency
        System.out.println("Please enter conversion string: ");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        String[] request=null;
        if(input!=null)
        request = input.split(" ");
        // call fx calculator method for conversion
        System.out.println(calc.fxCalculator(request));
        }

    }
}

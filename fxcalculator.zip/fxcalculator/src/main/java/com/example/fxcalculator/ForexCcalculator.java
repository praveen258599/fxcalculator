package com.example.fxcalculator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.util.HashMap;

public class ForexCcalculator {

    /**
     * This program converts currencies from one to other.
     * required input in <ccy1> <amount1> in <ccy2>
     * ex: AUD 100 in DKK
     *
     * @author  Praveen Bandidoddi
     * @version 1.0
     * @since   2018-06-26
     */
    public String fxCalculator(String[] request)
    {
        AppConfiguration config = new AppConfiguration();
        Logger logger = LoggerFactory.getLogger(ForexCcalculator.class);
        String sourceCurrency=null;
        String destinationCurrency=null;
        String returnString=null;

        try {
            String lookupCurrency=null;
            String inverseCurrency=null;
            float amount=0;
            float convertedAmount = 0;
            DecimalFormat df = new DecimalFormat("0.00");
            DecimalFormat jdf = new DecimalFormat("0");
            HashMap<Integer,String> currencies= config.getCurrencies();
            logger.info("List of Currencies Supported:"+currencies);
            HashMap<String,Float> conversion = config.getConversion();
            logger.info("Conversion Rates:"+currencies);
            HashMap<String,String> lookup= config.getLookup();
            logger.info("Currency Lookup Table"+lookup);

            if (request !=null) {
                sourceCurrency = request[0];
                destinationCurrency = request[3];
                amount = Float.parseFloat(request[1]);
                logger.debug("Currency Conversion from: "+sourceCurrency+" to "+destinationCurrency);
            }

            if(sourceCurrency !=null && destinationCurrency !=null) {
                lookupCurrency = sourceCurrency.concat(destinationCurrency);
                inverseCurrency = destinationCurrency.concat(sourceCurrency);
                logger.debug("lookup conversion currency: "+lookupCurrency+" & Inverse: "+destinationCurrency);
            }

            if (currencies.containsValue(sourceCurrency) && currencies.containsValue(destinationCurrency)) {

                //conversion logic using conversion and lookup table
                if (sourceCurrency.equalsIgnoreCase(destinationCurrency)) {
                    convertedAmount = amount;
                    logger.debug("No Conversion Required as same source and destination currency are same");
                } else if (conversion.containsKey(lookupCurrency)) {
                    convertedAmount = (conversion.get(lookupCurrency) * amount);
                    logger.debug("Direct Conversion available and converted amount: "+convertedAmount);
                } else if (conversion.containsKey(inverseCurrency)) {
                    convertedAmount = ((1 / (conversion.get(inverseCurrency))) * amount);
                    logger.debug("Conversion upon inversion and converted amount: "+convertedAmount);
                } else if (lookup.containsKey(lookupCurrency) || lookup.containsKey(inverseCurrency)) {

                    logger.debug("Entering cross currency conversion logic as no direct conversion available");
                    String firstLookup = sourceCurrency.concat(lookup.containsKey(lookupCurrency) ? lookup.get(lookupCurrency) : lookup.get(inverseCurrency));
                    String firstLookupInverse = lookup.containsKey(lookupCurrency) ? lookup.get(lookupCurrency).concat(sourceCurrency) : lookup.get(inverseCurrency).concat(sourceCurrency);
                    String lastLookup = lookup.containsKey(lookupCurrency) ? lookup.get(lookupCurrency).concat(destinationCurrency) : lookup.get(inverseCurrency).concat(destinationCurrency);
                    String lastLookupInverse = destinationCurrency.concat(lookup.containsKey(lookupCurrency) ? lookup.get(lookupCurrency) : lookup.get(inverseCurrency));
                    logger.debug("cross currency conversion:"+firstLookup+" and then "+lastLookup);

                    if (conversion.containsKey(firstLookup)) {
                        convertedAmount = conversion.get(firstLookup) * amount;
                    } else if (conversion.containsKey(firstLookupInverse)) {
                        convertedAmount = ((1 / (conversion.get(firstLookupInverse))) * amount);
                    }
                    else if(lookup.containsKey(firstLookup) || lookup.containsKey(firstLookupInverse))
                    {
                        logger.debug("Another lookup logic as no direct cross conversion available");
                        String intermediateLookup = lookup.containsKey(firstLookup)? sourceCurrency.concat(lookup.get(firstLookup)):sourceCurrency.concat(lookup.get(firstLookupInverse));
                        String intermediateLookupInverse = lookup.containsKey(firstLookup)? lookup.get(firstLookup).concat(sourceCurrency):lookup.get(firstLookupInverse).concat(sourceCurrency);
                        String intermediateLookup1 = lookup.containsKey(firstLookup)? lookup.get(firstLookup).concat(firstLookup.substring(3,6)):lookup.get(firstLookupInverse).concat(firstLookup.substring(3,6));
                        String intermediateLookupInverse1 = lookup.containsKey(firstLookup)? firstLookup.substring(3,6).concat(lookup.get(firstLookup)):firstLookup.substring(3,6).concat(lookup.get(firstLookupInverse));
                        logger.debug("cross currency conversion:"+intermediateLookup+"/"+intermediateLookupInverse+" and then "+intermediateLookup1+"/"+intermediateLookupInverse1);

                        if(conversion.containsKey(intermediateLookup)) {
                            convertedAmount = (conversion.get(intermediateLookup))*amount;
                        }
                        else {
                            convertedAmount =  (1 / (conversion.get(intermediateLookupInverse)))* amount;
                        }
                        if(conversion.containsKey(intermediateLookup1)) {
                            convertedAmount = convertedAmount * conversion.get(intermediateLookup1);
                        }
                        else {
                            convertedAmount = convertedAmount * (1 / conversion.get(intermediateLookupInverse1));
                        }
                    }
                    logger.debug("Intermediate converted amount is:"+firstLookup.substring(3,6)+" "+convertedAmount);

                    if (conversion.containsKey(lastLookup)) {
                        convertedAmount = convertedAmount * conversion.get(lastLookup);
                    } else if (conversion.containsKey(lastLookupInverse)) {
                        convertedAmount = convertedAmount * (1 / (conversion.get(lastLookupInverse)));
                    }
                    else if(lookup.containsKey(lastLookup) || lookup.containsKey(lastLookupInverse))
                    {
                        logger.debug("Another lookup logic as no direct cross conversion available");
                        String intermediateLookup = lookup.containsKey(lastLookup)? lastLookup.substring(0,3).concat(lookup.get(lastLookup)):lastLookup.substring(0,3).concat(lookup.get(lastLookupInverse));
                        String intermediateLookupInverse = lookup.containsKey(lastLookup)? lookup.get(lastLookup).concat(lastLookup.substring(0,3)):lookup.get(lastLookupInverse).concat(lastLookup.substring(0,3));
                        String intermediateLookup1 = lookup.containsKey(lastLookup)? lookup.get(lastLookup).concat(destinationCurrency):lookup.get(lastLookupInverse).concat(destinationCurrency);
                        String intermediateLookupInverse1 = lookup.containsKey(lastLookup)? destinationCurrency.concat(lookup.get(lastLookup)):destinationCurrency.concat(lookup.get(lastLookupInverse));
                        logger.debug("cross currency conversion:"+intermediateLookup+"/"+intermediateLookupInverse+" and then "+intermediateLookup1+"/"+intermediateLookupInverse1);

                        if(conversion.containsKey(intermediateLookup)) {
                            convertedAmount = convertedAmount * conversion.get(intermediateLookup);
                        }
                        else {
                            convertedAmount = convertedAmount * (1 / conversion.get(intermediateLookupInverse));
                        }
                        if(conversion.containsKey(intermediateLookup1)) {
                            convertedAmount = convertedAmount * conversion.get(intermediateLookup1);
                        }
                        else {
                            convertedAmount = convertedAmount * (1 / conversion.get(intermediateLookupInverse1));
                        }
                    }
                }
                //set return string and set the decimal places for the converted amount
                if(convertedAmount!=0) {
                    logger.debug("Final Converted Amount: "+destinationCurrency+" "+convertedAmount);
                    if (destinationCurrency.equalsIgnoreCase("JPY")) {
                        returnString=(sourceCurrency + " " + amount + " = " + destinationCurrency + " " + jdf.format(convertedAmount));
                    } else {
                        returnString=(sourceCurrency + " " + amount + " = " + destinationCurrency + " " + df.format(convertedAmount));
                    }

                }

            }
            //Set user friendly message about unable to convert the currency
            if(convertedAmount==0){
                returnString="Unable to find rate for "+sourceCurrency+"/"+destinationCurrency;
            }

        } catch (Exception e) {
            //When unable to convert due to exception, display a friendly message
            logger.info("Exception :: " , e);
            if(sourceCurrency!=null && destinationCurrency!=null)
                returnString="Unable to find rate for "+sourceCurrency+"/"+destinationCurrency;
            else
                returnString="No Inputs Provided";
        }
    return returnString;
    }
}
